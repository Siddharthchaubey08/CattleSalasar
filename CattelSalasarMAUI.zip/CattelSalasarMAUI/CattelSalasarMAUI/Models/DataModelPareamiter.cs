﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CattelSalasarMAUI.Models
{
    public class DataModelPareamiter
    {
        public int Id { get; set; }
        public int PropId { get; set; }
        public string LeadNumber { get; set; }
        public string Species { get; set; }
        
    }
}
