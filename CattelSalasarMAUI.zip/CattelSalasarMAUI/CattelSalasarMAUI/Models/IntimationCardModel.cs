﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CattelSalasarMAUI.Models
{
    public class IntimationCardModel
    {
        public string Propid { get; set; }
        public string PolicyNo { get; set; }
        public string LeadNumber { get; set; }
        public string SurveyDate { get; set; }
        public string CustomerName { get; set; }
        public string AadharNumber { get; set; }
        public string CustomerMobile { get; set; }
        public string CreatedDate { get; set; }
    }
}
