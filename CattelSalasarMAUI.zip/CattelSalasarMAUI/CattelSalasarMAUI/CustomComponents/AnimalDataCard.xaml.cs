namespace CattelSalasarMAUI.CustomComponents;

public partial class AnimalDataCard : ContentView
{
	public AnimalDataCard()
	{
		InitializeComponent();
	}
}