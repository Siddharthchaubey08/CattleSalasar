namespace CattelSalasarMAUI.CustomComponents;

public partial class DataCardView : ContentView
{
	public DataCardView()
	{
		InitializeComponent();
	}
}