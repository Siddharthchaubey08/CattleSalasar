namespace CattelSalasarMAUI.CustomComponents;

public partial class ClaimCardView : ContentView
{
	public ClaimCardView()
	{
		InitializeComponent();
	}
}