namespace CattelSalasarMAUI.CustomComponents;

public partial class EditAnimalDataCard : ContentView
{
	public EditAnimalDataCard()
	{
		InitializeComponent();
	}
}