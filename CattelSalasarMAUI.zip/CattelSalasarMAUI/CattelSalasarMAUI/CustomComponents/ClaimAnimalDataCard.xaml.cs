namespace CattelSalasarMAUI.CustomComponents;

public partial class ClaimAnimalDataCard : ContentView
{
	public ClaimAnimalDataCard()
	{
		InitializeComponent();
	}
}