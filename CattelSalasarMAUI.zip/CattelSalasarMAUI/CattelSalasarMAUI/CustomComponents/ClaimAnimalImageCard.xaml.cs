namespace CattelSalasarMAUI.CustomComponents;

public partial class ClaimAnimalImageCard : ContentView
{
	public ClaimAnimalImageCard()
	{
		InitializeComponent();
	}
}